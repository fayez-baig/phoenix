<?php
$servername = "localhost";
$username = "id4307626_phoenix_tutorials";
$password = "phoenix_tutorials";
$dbname = "id4307626_phoenix_tutorials";

?>