<?php 

   include_once('login_check.php');


 ?>
 <!-- footer content -->
	<footer>
	  <div class="pull-right">
	     Phoenix Tutorials - Admin Panel by <a href="javascript:void(0)">IT Diploma Student</a>
	  </div>
	  <div class="clearfix"></div>
	</footer>
<!-- /footer content -->